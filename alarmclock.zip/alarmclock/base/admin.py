from django.contrib import admin
from .models import Time
# Register your models here.
admin.site.register(Time)
